/* CMPT 435
 * Project 1 Milestone 2 -- Maze
 * Filename: Driver_prj1.java
 * Student name: Rafael Marmol
 *
 * Program which takes input in form of a maze and outputs solution path from start to endline
 *
 * Class: Driver_prj1
 */

import java.util.Scanner;
public class Driver_prj1 {

  /* main
   *  parameters:
   *      args -- the array of command line argument values
   *  return value: nothing
   * 
   *  runs main method of program or the actual trace
   */
  public static void main(String[] args) {
      //sets up scanner input (not from files -- for now)
      Scanner input = new Scanner(System.in);
      //set up test locations
      Location loc1 = new Location();
      loc1.streamIn(input);
      LocationStackNode node1 = new LocationStackNode(loc1, null);
      Location loc2 = new Location();
      loc2.streamIn(input);
      LocationStackNode node2 = new LocationStackNode(loc2, null);
      Location loc3 = new Location();
      loc3.streamIn(input);
      LocationStackNode node3 = new LocationStackNode(loc3, null);
      
      Location loc4 = new Location();
      loc4.streamIn(input);
      
      //set up test stack
      LocationStack stack = new LocationStack();
      stack.push(node1.getLocation());
      stack.push(node2.getLocation());
      stack.push(node3.getLocation());
      
      stack.streamOut(stack);
      
      
      //test compare locations
      if(stack.isOn(loc4)){
        System.out.println("Yes");
      }
      else {
        System.out.println("No");
      }
  }
  
 }